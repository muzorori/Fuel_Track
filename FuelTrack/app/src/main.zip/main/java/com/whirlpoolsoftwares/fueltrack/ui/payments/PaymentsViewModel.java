package com.whirlpoolsoftwares.fueltrack.ui.payments;

import androidx.lifecycle.ViewModel;

public class PaymentsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}
