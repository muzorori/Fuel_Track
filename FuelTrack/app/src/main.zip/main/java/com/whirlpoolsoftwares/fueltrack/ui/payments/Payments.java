package com.whirlpoolsoftwares.fueltrack.ui.payments;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;


import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.android.material.button.MaterialButton;
import com.google.android.material.textfield.TextInputEditText;
import com.whirlpoolsoftwares.fueltrack.R;

import zw.co.paynow.constants.MobileMoneyMethod;
import zw.co.paynow.core.Payment;
import zw.co.paynow.core.Paynow;
import zw.co.paynow.responses.MobileInitResponse;

public class Payments extends Fragment {

    private PaymentsViewModel mViewModel;
    private String instructions;
    private boolean paymentSuccess = false;

    public static Payments newInstance() {
        return new Payments();
    }
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.payments_fragment, container, false);
        final TextInputEditText text = root.findViewById(R.id.phone_no);
        final Spinner spinner = root.findViewById(R.id.payments_options);
        MaterialButton pay = root.findViewById(R.id.make_payment);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(getContext(),
                R.array.options, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);
        final StringBuilder builder = new StringBuilder();
        spinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                builder.setLength(0);
                String methodOfPayment = spinner.getSelectedItem().toString();
                builder.append(methodOfPayment);
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {

            }
        });

        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String methodOfPayment = builder.toString();
//                Thread thread = new Thread(new Runnable() {
//                    @Override
//                    public void run() {
//                        try{
//                        MobileMoneyMethod method = MobileMoneyMethod.ECOCASH;
//
//                        if(methodOfPayment.equals("Ecocash"))
//                            method = MobileMoneyMethod.ECOCASH;
//                        else if(methodOfPayment.equals("One Money"))
//                            method = MobileMoneyMethod.ONEMONEY;
//
//                        makePayment(text.getText().toString(),method);
//
//                        }catch (Exception e){
//                            e.printStackTrace();
//                        }
//                    }
//                });
//
//                thread.start();

                //Toast.makeText(getContext(),instructions,Toast.LENGTH_LONG).show();
                makePaymentDummy(text.getText().toString());
            }
        });

        return root;
    }

    private void makePayment(String number, MobileMoneyMethod method){
        Paynow paynow = new Paynow("6668", "b0b170e0-c950-4800-b56c-9ce4e4e02e14");
        Payment payment = paynow.createPayment("Invoice 3278WJSD", "mkunadavy@gmail.com");
        payment.add("Search Fee", 1.0);
        MobileInitResponse response = paynow.sendMobile(payment, number,method);

        Log.e("Response",response.getInstructions());

        if (response.success()) {
            // Get the instructions to show to the user
            instructions  = response.instructions();
            Log.e("Response",instructions);
            // Get the poll URL of the transaction
            String pollUrl = response.pollUrl();
        } else {
            Log.e("Response","No response from server");
        }
    }

    private void makePaymentDummy(String number){
        if(!number.isEmpty()){
            paymentSuccess = true;
            String fuel = getArguments().getString("fuel");
            SharedPreferences preferences = getActivity().getSharedPreferences("fuels", Context.MODE_PRIVATE);
            SharedPreferences.Editor editor = preferences.edit();
            editor.putBoolean(fuel,paymentSuccess);
            editor.apply();
            //Toast.makeText(getContext(),fuel,Toast.LENGTH_LONG).show();

            //payment successful
            //open map
            //change navbar selected option
            //change toolbar text
        }

        if(paymentSuccess){
            ((AppCompatActivity)getActivity()).getSupportActionBar().setTitle("Map");
            BottomNavigationView bottomNavigationView = getActivity().findViewById(R.id.nav_view);
            //bottomNavigationView.setSelectedItemId(R.id.navigation_map);
        }
    }
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        //mViewModel = new ViewModelProvider(this).get(PaymentsViewModel.class);
        // TODO: Use the ViewModel
    }




}
